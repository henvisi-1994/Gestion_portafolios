"""GestionPortafolios URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from Gestion import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.test),
    path('inicio', views.inicio),
    path('gestion', views.gestion_portafolio),
    path('datosInformativos', views.datos_informativos),
    path('distribucionDiarios', views.distribucion_diarios),
    path('proyecto', views.proyecto),
    path('intraclases', views.tareas_intraclase),
    path('extraclases', views.tareas_extraclase),
    path('practicalaboratorio', views.practica_laboratorio),
    path('evaluaciones', views.evaluaciones),
    path('examenes', views.examenes),
    path('anexos', views.anexos),
    path('crearPortafolios', views.crear_portafolios),
    path('visualizarPortafolios', views.visualizar_portafolios),
    path('eliminarPortafolios', views.eliminar_portafolios),
    path('matriculaEst', views.matricula_est),
    path('aulasVirtuales', views.aulas_virtuales),
    path('diario', views.diarios),
    path('listaDiarios', views.lista_diarios),
    path('misPortEst', views.mis_port_est),

]
